import time
import os
import math
import argparse
from glob import glob
from collections import OrderedDict
import random
import warnings
from datetime import datetime
import joblib
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


import numpy as np
import pandas as pd

from sklearn.model_selection import KFold, StratifiedKFold
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA

import keras
from keras.datasets import mnist
from keras.preprocessing.image import ImageDataGenerator
from keras.models import Sequential, load_model, Model
from keras.layers import Dense, Dropout, Activation, Flatten
from keras.layers import Conv2D, MaxPooling2D
from keras.optimizers import SGD, Adam
from keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau, CSVLogger, LearningRateScheduler

import archs
from metrics import *

from imutils import paths
import cv2
from sklearn.preprocessing import LabelEncoder
from keras.utils import np_utils
from imageio import imread
from skimage.transform import resize

def load_and_align_images(filepaths, margin, image_size):
    cascade = cv2.CascadeClassifier('models/cv2/haarcascade_frontalface_alt2.xml')
    
    aligned_images = []
    for filepath in filepaths:
        print(filepath)
        img = imread(filepath)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = cascade.detectMultiScale(gray,
                                         scaleFactor=1.1,
                                         minNeighbors=3)
        (x, y, w, h) = faces[0]
        img = img / 255
        cropped = img[y-margin//2:y+h+margin//2,
                      x-margin//2:x+w+margin//2, :]
        aligned = cv2.resize(cropped, (64, 64))
        aligned_images.append(aligned)
        #cv2.imwrite('1.jpg',aligned)
            
    return np.array(aligned_images)

def main():
    # dataset
    '''(X, y), (X_test, y_test) = mnist.load_data()

    X = X[:, :, :, np.newaxis].astype('float32') / 255
    X_test = X_test[:, :, :, np.newaxis].astype('float32') / 255
    y_ohe = keras.utils.to_categorical(y, 10)
    y_ohe_test = keras.utils.to_categorical(y_test, 10)'''
    test_dir_basepath = 'C:/Users/Administrator/Desktop/cisc499/keras-arcface-try/photo/Test3/'
    X_test = None
    image_size = 64
    y_test = np.array([])
    test_filepaths = [os.path.join(test_dir_basepath, s) for s in os.listdir(test_dir_basepath)]
    print(test_filepaths)
    #np.array([np.array(x) for x in [[0,0,1],[0,0,1],[0,0,1],[1,0,0],[1,0,0],[1,0,0],[0,1,0],[0,1,0],[0,1,0]]])):
    y_test = np.array([[0,0,1],[0,0,1],[0,0,1],[0,0,1],[0,0,1],[0,0,1],[0,0,1],[1,0,0],[1,0,0],[1,0,0],[1,0,0],[1,0,0],[1,0,0],[1,0,0],[0,1,0],[0,1,0],[0,1,0],[0,1,0],[0,1,0],[0,1,0],[0,1,0]])
    #test_filepaths = [os.path.join(test_dir_basepath, s)]
    X_test = load_and_align_images(test_filepaths, 10, image_size)

    # feature extraction
    '''softmax_model = load_model('models/mnist_vgg8_3d/model.hdf5')
    softmax_model = Model(inputs=softmax_model.input, outputs=softmax_model.layers[-2].output)
    softmax_features = softmax_model.predict(X_test, verbose=1)
    softmax_features /= np.linalg.norm(softmax_features, axis=1, keepdims=True)

    cosface_model = load_model('models/mnist_vgg8_cosface_3d/model.hdf5', custom_objects={'CosFace': CosFace})
    cosface_model = Model(inputs=cosface_model.input[0], outputs=cosface_model.layers[-3].output)
    cosface_features = cosface_model.predict(X_test, verbose=1)
    cosface_features /= np.linalg.norm(cosface_features, axis=1, keepdims=True)'''

    arcface_model = load_model('models/mnist_vgg8_arcface_3d/model.hdf5', custom_objects={'ArcFace': ArcFace})
    arcface_model = Model(inputs=arcface_model.input[0], outputs=arcface_model.layers[-3].output)
    arcface_features = arcface_model.predict(X_test, verbose=1)
    arcface_features /= np.linalg.norm(arcface_features, axis=1, keepdims=True)
    for feature in arcface_features:
        print(np.argmax(feature))
    #print(arcface_features)
    '''sphereface_model = load_model('models/mnist_vgg8_sphereface_3d/model.hdf5', custom_objects={'SphereFace': SphereFace})
    sphereface_model = Model(inputs=sphereface_model.input[0], outputs=sphereface_model.layers[-3].output)
    sphereface_features = sphereface_model.predict(X_test, verbose=1)
    sphereface_features /= np.linalg.norm(sphereface_features, axis=1, keepdims=True)

    # plot
    fig1 = plt.figure()
    ax1 = Axes3D(fig1)
    for c in range(len(np.unique(y_test))):
        ax1.plot(softmax_features[y_test==c, 0], softmax_features[y_test==c, 1], softmax_features[y_test==c, 2], '.', alpha=0.1)
    plt.title('Softmax')

    fig2 = plt.figure()
    ax2 = Axes3D(fig2)
    for c in range(len(np.unique(y_test))):
        ax2.plot(arcface_features[y_test==c, 0], arcface_features[y_test==c, 1], arcface_features[y_test==c, 2], '.', alpha=0.1)
    plt.title('ArcFace')

    fig3 = plt.figure()
    ax3 = Axes3D(fig3)
    for c in range(len(np.unique(y_test))):
        ax3.plot(cosface_features[y_test==c, 0], cosface_features[y_test==c, 1], cosface_features[y_test==c, 2], '.', alpha=0.1)
    plt.title('CosFace')

    fig4 = plt.figure()
    ax4 = Axes3D(fig4)
    for c in range(len(np.unique(y_test))):
        ax4.plot(sphereface_features[y_test==c, 0], sphereface_features[y_test==c, 1], sphereface_features[y_test==c, 2], '.', alpha=0.1)
    plt.title('SphereFace')

    plt.show()'''


if __name__ == '__main__':
    main()
